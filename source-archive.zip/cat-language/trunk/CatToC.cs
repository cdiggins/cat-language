﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Cat
{
    public class CatToC
    {
        StringBuilder sb = new StringBuilder();

        public void Initialize()
        {
            sb = new StringBuilder();
        }


        public void Convert(DefinedFunction x)
        {
            // TODO:
        }

        public void Convert(CatExpr x)
        {
            // TODO:
        }

        public void Convert(PushValueBase x)
        {
            // TODO:
        }
    }
}
