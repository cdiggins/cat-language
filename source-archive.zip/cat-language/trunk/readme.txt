Cat Interpreter, http://www.cat-language.com
Copyright 2008, by Christopher Diggins

Executable licensed under the MIT License (see license.txt)
All source files are public domain

NOTE:
Don't forget to load the standard library by passing "everything.cat" as a command-line argument.

To compile the source code you can use the Microsoft Visual C# Express edition.
You can download it for free at:

  http://msdn.microsoft.com/vstudio/express/visualcsharp/

Or the open-source Mono compiler version 1.2 or later:

  http://www.mono-project.com/Downloads

To compile with mono on Windows use the files "mono_build.bat", or if graphics give you a problem
use "no_graphics_mono_build.bat". If you are using Mac, Linux, or other, open these files to see
the neccessary command-line options for running Mono.

To report bugs go to:

  http://code.google.com/p/cat-language/issues/list

To get the latest download go to:

  http://code.google.com/p/cat-language/downloads/list

To join the Cat discussion group and mailing list go to:

  http://groups.google.com/group/catlanguage

For a Cat tutorial go to:

  http://www.cat-language.com/tutorial.html

The Cat manual/specification is at:

  http://www.cat-language.com/manual.html

Most importantly, have fun!

Christopher Diggins
http://www.cdiggins.com