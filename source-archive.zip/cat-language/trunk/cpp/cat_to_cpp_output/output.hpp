// C++ file generated from Cat input
// created using the Cat to C++ tool
// by Christopher Diggins

// http://www.cat-language.com

void _apply();
void _apply2();
void _dip();
void _dip2();
void _b();
void _c();
void _d();
void _i();
void _k();
void _ki();
void _l();
void _m();
void _o();
void _r();
void _s();
void _t();
void _u();
void _v();
void _w();
void _y();
void _and();
void _nand();
void _nor();
void _not();
void _or();
void _eqz();
void _eqf();
void _neq();
void _neqf();
void _neqz();
void _curry();
void _curry2();
void _rcompose();
void _rcurry();
void _for();
void _for__each();
void _repeat();
void _rfor();
void _whilen();
void _whilene();
void _whilenz();
void _cat();
void _consd();
void _count();
void _count__while();
void _drop();
void _drop__while();
void _filter();
void _first();
void _flatten();
void _fold();
void _gen();
void _head();
void _last();
void _map();
void _mid();
void _move__head();
void _n();
void _nth();
void _pair();
void _rev();
void _rmap();
void _set__at();
void _small();
void _split();
void _split__at();
void _swons();
void _tail();
void _take();
void _take__while();
void _triple();
void _unpair();
void _unit();
void _bury();
void _dig();
void _dup2();
void _dupd();
void _over();
void _peek();
void _poke();
void _pop2();
void _pop3();
void _popd();
void _swap2();
void _swapd();
void _under();
void _dec();
void _even();
void _inc();
void _sub__int();
void _min__int();
void _max__int();
void _odd();
void _gt__int();
void _gteq__int();
void _lteq__int();
void _run__tests();
void _cat_anon0();
void _cat_anon1();
void _cat_anon2();
void _cat_anon3();
void _cat_anon4();
void _cat_anon5();
void _cat_anon6();
void _cat_anon7();
void _cat_anon8();
void _cat_anon9();
void _cat_anon10();
void _cat_anon11();
void _cat_anon12();
void _cat_anon13();
void _cat_anon14();
void _cat_anon15();
void _cat_anon16();
void _cat_anon17();
void _cat_anon18();
void _cat_anon19();
void _cat_anon20();
void _cat_anon21();
void _cat_anon22();
void _cat_anon23();
void _cat_anon24();
void _cat_anon25();
void _cat_anon26();
void _cat_anon27();
void _cat_anon28();
void _cat_anon29();
void _cat_anon30();
void _cat_anon31();
void _cat_anon32();
void _cat_anon33();
void _cat_anon34();
void _cat_anon35();
void _cat_anon36();
void _cat_anon37();
void _cat_anon38();
void _cat_anon39();
void _cat_anon40();
void _cat_anon41();
void _cat_anon42();
void _cat_anon43();
void _cat_anon44();
void _cat_anon45();
void _cat_anon46();
void _cat_anon47();
void _cat_anon48();
void _cat_anon49();
void _cat_anon50();
void _cat_anon51();
void _cat_anon52();
void _cat_anon53();
void _cat_anon54();
void _cat_anon55();
void _cat_anon56();
void _cat_anon57();
void _cat_anon58();
void _cat_anon59();
void _cat_anon60();
void _cat_anon61();
void _cat_anon62();
void _cat_anon63();
void _cat_anon64();
void _cat_anon65();
void _cat_anon66();
void _cat_anon67();
void _cat_anon68();
void _cat_anon69();
void _cat_anon70();
void _cat_anon71();
void _cat_anon72();
void _cat_anon73();
void _cat_anon74();
void _cat_anon75();
void _cat_anon76();
void _cat_anon77();
void _cat_anon78();
void _cat_anon79();
void _cat_anon80();
void _cat_anon81();
void _cat_anon82();
void _cat_anon83();
void _cat_anon84();
void _cat_anon85();
void _cat_anon86();
void _cat_anon87();
void _cat_anon88();
void _cat_anon89();
void _cat_anon90();
void _cat_anon91();
void _cat_anon92();
void _cat_anon93();
void _cat_anon94();
void _cat_anon95();
void _cat_anon96();
void _cat_anon97();
void _cat_anon98();
void _cat_anon99();
void _cat_anon100();
void _cat_anon101();
void _cat_anon102();
void _cat_anon103();
void _cat_anon104();
void _cat_anon105();
void _cat_anon106();
void _cat_anon107();
void _cat_anon108();
void _cat_anon109();
void _cat_anon110();
void _cat_anon111();
void _cat_anon112();
void _cat_anon113();
void _cat_anon114();
void _cat_anon115();
void _cat_anon116();
void _cat_anon117();
void _cat_anon118();
void _cat_anon119();
void _cat_anon120();
void _cat_anon121();
void _cat_anon122();
void _cat_anon123();
void _cat_anon124();
void _cat_anon125();
void _cat_anon126();
void _cat_anon127();
void _cat_anon128();
void _cat_anon129();
void _cat_anon130();
void _cat_anon131();
void _cat_anon132();
void _cat_anon133();
void _cat_anon134();
void _cat_anon135();
void _cat_anon136();
void _cat_anon137();
void _cat_anon138();
void _cat_anon139();
void _cat_anon140();
void _cat_anon141();
void _cat_anon142();
void _cat_anon143();
void _cat_anon144();
void _cat_anon145();
void _cat_anon146();
void _cat_anon147();
void _cat_anon148();
void _cat_anon149();
void _cat_anon150();
void _cat_anon151();
void _cat_anon152();
void _cat_anon153();
void _cat_anon154();
void _cat_anon155();
void _cat_anon156();
void _cat_anon157();
void _cat_anon158();
void _cat_anon159();
void _cat_anon160();
void _cat_anon161();
void _cat_anon162();
void _cat_anon163();
void _cat_anon164();
void _cat_anon165();
void _cat_anon166();
void _cat_anon167();
void _cat_anon168();
void _cat_anon169();
void _cat_anon170();
void _cat_anon171();
void _cat_anon172();
void _cat_anon173();
void _cat_anon174();
void _cat_anon175();
void _cat_anon176();
void _cat_anon177();
void _cat_anon178();
void _cat_anon179();
void _cat_anon180();
void _cat_anon181();
void _cat_anon182();
void _cat_anon183();
void _cat_anon184();
void _cat_anon185();
void _cat_anon186();
void _cat_anon187();
void _cat_anon188();
void _cat_anon189();
void _cat_anon190();
void _cat_anon191();
void _cat_anon192();
void _cat_anon193();
void _cat_anon194();
void _cat_anon195();
void _cat_anon196();
void _cat_anon197();
void _cat_anon198();
void _cat_anon199();
void _cat_anon200();
void _cat_anon201();
void _cat_anon202();
void _cat_anon203();
void _cat_anon204();
void _cat_anon205();
void _cat_anon206();
void _cat_anon207();
void _cat_anon208();
void _cat_anon209();
void _cat_anon210();
void _cat_anon211();
void _cat_anon212();
void _cat_anon213();
void _cat_anon214();
void _cat_anon215();
void _cat_anon216();
void _cat_anon217();
void _cat_anon218();
void _cat_anon219();
void _cat_anon220();
void _cat_anon221();
void _cat_anon222();
void _cat_anon223();
void _cat_anon224();
void _cat_anon225();
void _cat_anon226();
void _cat_anon227();
void _cat_anon228();
void _cat_anon229();
void _cat_anon230();
void _apply()
{
    call(_true);
    call(_swap);
    push_function(_cat_anon0); //[]
    call(_if);
}
void _apply2()
{
    call(_under);
    call(_apply);
    push_function(_cat_anon1); //[apply]
    call(_dip);
}
void _dip()
{
    call(_swap);
    call(_quote);
    call(_compose);
    call(_apply);
}
void _dip2()
{
    call(_swap);
    push_function(_cat_anon2); //[dip]
    call(_dip);
}
void _b()
{
    push_function(_cat_anon3); //[k]
    push_function(_cat_anon5); //[[s] k]
    call(_s);
}
void _c()
{
    push_function(_cat_anon7); //[[k] k]
    push_function(_cat_anon10); //[[s] [b] b]
    call(_s);
}
void _d()
{
    push_function(_cat_anon11); //[b]
    call(_b);
}
void _i()
{
    push_function(_cat_anon12); //[k]
    push_function(_cat_anon13); //[k]
    call(_s);
}
void _k()
{
    push_function(_cat_anon14); //[pop]
    call(_dip);
}
void _ki()
{
    push_function(_cat_anon15); //[i]
    call(_k);
}
void _l()
{
    push_function(_cat_anon16); //[m]
    push_function(_cat_anon17); //[b]
    call(_c);
}
void _m()
{
    call(_dup);
    call(_apply);
}
void _o()
{
    push_function(_cat_anon18); //[i]
    call(_s);
}
void _r()
{
    push_function(_cat_anon19); //[t]
    push_function(_cat_anon20); //[b]
    call(_b);
}
void _s()
{
    call(_peek);
    call(_swap);
    push_function(_cat_anon21); //[curry]
    call(_dip2);
    call(_apply);
}
void _t()
{
    push_function(_cat_anon22); //[i]
    call(_c);
}
void _u()
{
    push_function(_cat_anon23); //[o]
    call(_l);
}
void _v()
{
    push_function(_cat_anon24); //[t]
    push_function(_cat_anon25); //[c]
    call(_b);
}
void _w()
{
    push_function(_cat_anon28); //[[r] [m] b]
    call(_c);
}
void _y()
{
    call(_dup);
    call(_quote);
    push_function(_cat_anon29); //[y]
    call(_compose);
    call(_swap);
    call(_apply);
}
void _and()
{
    call(_quote);
    push_function(_cat_anon30); //[false]
    call(_if);
}
void _nand()
{
    call(_and);
    call(_not);
}
void _nor()
{
    call(_or);
    call(_not);
}
void _not()
{
    push_function(_cat_anon31); //[false]
    push_function(_cat_anon32); //[true]
    call(_if);
}
void _or()
{
    push_function(_cat_anon33); //[true]
    call(_swap);
    call(_quote);
    call(_if);
}
void _eqz()
{
    call(_dup);
    push_literal(0 );
    call(_eq);
}
void _eqf()
{
    push_function(_cat_anon34); //[dupd eq]
    call(_curry);
}
void _neq()
{
    call(_eq);
    call(_not);
}
void _neqf()
{
    push_function(_cat_anon35); //[dupd neq]
    call(_curry);
}
void _neqz()
{
    call(_dup);
    push_literal(0 );
    call(_neq);
}
void _curry()
{
    push_function(_cat_anon36); //[quote]
    call(_dip);
    call(_compose);
}
void _curry2()
{
    call(_curry);
    call(_curry);
}
void _rcompose()
{
    call(_swap);
    call(_compose);
}
void _rcurry()
{
    call(_swap);
    call(_curry);
}
void _for()
{
    call(_swap);
    push_function(_cat_anon37); //[dip inc]
    call(_curry);
    push_function(_cat_anon38); //[dup]
    call(_rcompose);
    call(_swap);
    call(_neqf);
    push_literal(0 );
    call(_bury);
    call(_while);
    call(_pop);
}
void _for__each()
{
    push_function(_cat_anon39); //[dip]
    call(_curry);
    push_function(_cat_anon40); //[uncons swap]
    call(_rcompose);
    call(_whilene);
}
void _repeat()
{
    call(_swap);
    push_function(_cat_anon41); //[dip dec]
    call(_curry);
    push_function(_cat_anon42); //[neqz]
    call(_while);
    call(_pop);
}
void _rfor()
{
    call(_swap);
    push_function(_cat_anon43); //[dip dec]
    call(_curry);
    push_function(_cat_anon44); //[dup]
    call(_rcompose);
    call(_whilenz);
}
void _whilen()
{
    push_function(_cat_anon45); //[not]
    call(_compose);
    call(_while);
}
void _whilene()
{
    push_function(_cat_anon46); //[empty not]
    call(_while);
    call(_pop);
}
void _whilenz()
{
    push_function(_cat_anon47); //[neqz]
    call(_while);
    call(_pop);
}
void _cat()
{
    call(_rev);
    call(_swap);
    push_function(_cat_anon48); //[cons]
    call(_fold);
}
void _consd()
{
    push_function(_cat_anon49); //[cons]
    call(_dip);
}
void _count()
{
    call(_dup);
    push_literal(0 );
    push_function(_cat_anon50); //[pop inc]
    call(_fold);
}
void _count__while()
{
    push_function(_cat_anon51); //[dup 0 swap]
    call(_dip);
    push_function(_cat_anon53); //[[inc] dip]
    call(_swap);
    push_function(_cat_anon54); //[uncons]
    call(_rcompose);
    call(_while);
    call(_pop);
}
void _drop()
{
    push_function(_cat_anon56); //[[tail] dip dec]
    call(_whilenz);
}
void _drop__while()
{
    call(_count__while);
    call(_drop);
}
void _filter()
{
    push_function(_cat_anon57); //[rev]
    call(_dip);
    push_function(_cat_anon60); //[[cons] [pop] if]
    call(_compose);
    push_function(_cat_anon61); //[dup]
    call(_rcompose);
    call(_nil);
    call(_swap);
    call(_fold);
}
void _first()
{
    call(_dup);
    call(_uncons);
    call(_popd);
}
void _flatten()
{
    call(_rev);
    call(_nil);
    push_function(_cat_anon62); //[cat]
    call(_fold);
}
void _fold()
{
    call(_swapd);
    push_function(_cat_anon63); //[dip]
    call(_curry);
    push_function(_cat_anon64); //[uncons swap]
    call(_rcompose);
    call(_whilene);
}
void _gen()
{
    call(_nil);
    call(_swap);
    push_function(_cat_anon65); //[bury]
    call(_dip);
    push_function(_cat_anon67); //[[dup consd] rcompose]
    call(_dip);
    push_function(_cat_anon68); //[dup]
    call(_rcompose);
    call(_while);
    call(_pop);
}
void _head()
{
    call(_uncons);
    call(_popd);
}
void _last()
{
    call(_count);
    call(_dec);
    call(_nth);
}
void _map()
{
    call(_rmap);
    call(_rev);
}
void _mid()
{
    call(_count);
    push_literal(2 );
    call(_div__int);
    call(_nth);
}
void _move__head()
{
    call(_uncons);
    call(_swap);
    call(_consd);
}
void _n()
{
    call(_nil);
    call(_swap);
    push_function(_cat_anon69); //[cons]
    call(_swap);
    call(_for);
}
void _nth()
{
    call(_dupd);
    call(_drop);
    call(_head);
}
void _pair()
{
    push_function(_cat_anon70); //[unit]
    call(_dip);
    call(_cons);
}
void _rev()
{
    call(_nil);
    push_function(_cat_anon71); //[cons]
    call(_fold);
}
void _rmap()
{
    call(_nil);
    call(_swap);
    push_function(_cat_anon72); //[cons]
    call(_compose);
    call(_fold);
}
void _set__at()
{
    call(_swapd);
    call(_split__at);
    push_function(_cat_anon73); //[tail swons]
    call(_dip);
    call(_cat);
}
void _small()
{
    call(_count);
    push_literal(1 );
    call(_lteq__int);
}
void _split()
{
    call(_dup2);
    push_function(_cat_anon74); //[filter]
    call(_dip2);
    push_function(_cat_anon75); //[not]
    call(_compose);
    call(_filter);
}
void _split__at()
{
    call(_nil);
    call(_bury);
    push_function(_cat_anon76); //[move_head]
    call(_swap);
    call(_repeat);
    call(_swap);
}
void _swons()
{
    call(_swap);
    call(_cons);
}
void _tail()
{
    call(_uncons);
    call(_pop);
}
void _take()
{
    call(_nil);
    call(_bury);
    push_function(_cat_anon78); //[[move_head] dip dec]
    call(_whilenz);
    call(_pop);
    call(_rev);
}
void _take__while()
{
    call(_count__while);
    call(_take);
}
void _triple()
{
    push_function(_cat_anon79); //[pair]
    call(_dip);
    call(_cons);
}
void _unpair()
{
    call(_uncons);
    push_function(_cat_anon80); //[head]
    call(_dip);
}
void _unit()
{
    call(_nil);
    call(_swap);
    call(_cons);
}
void _bury()
{
    call(_swap);
    call(_swapd);
}
void _dig()
{
    call(_swapd);
    call(_swap);
}
void _dup2()
{
    call(_over);
    call(_over);
}
void _dupd()
{
    push_function(_cat_anon81); //[dup]
    call(_dip);
}
void _over()
{
    call(_dupd);
    call(_swap);
}
void _peek()
{
    push_function(_cat_anon82); //[dupd]
    call(_dip);
    call(_dig);
}
void _poke()
{
    push_function(_cat_anon83); //[popd]
    call(_dip);
    call(_swap);
}
void _pop2()
{
    call(_pop);
    call(_pop);
}
void _pop3()
{
    call(_pop);
    call(_pop);
    call(_pop);
}
void _popd()
{
    push_function(_cat_anon84); //[pop]
    call(_dip);
}
void _swap2()
{
    push_function(_cat_anon85); //[bury]
    call(_dip);
    call(_bury);
}
void _swapd()
{
    push_function(_cat_anon86); //[swap]
    call(_dip);
}
void _under()
{
    call(_dup);
    call(_swapd);
}
void _dec()
{
    push_literal(1 );
    call(_sub__int);
}
void _even()
{
    call(_dup);
    push_literal(2 );
    call(_mod__int);
    push_literal(0 );
    call(_eq);
}
void _inc()
{
    push_literal(1 );
    call(_add__int);
}
void _sub__int()
{
    call(_neg__int);
    call(_add__int);
}
void _min__int()
{
    call(_dup2);
    call(_gt__int);
    push_function(_cat_anon87); //[popd]
    push_function(_cat_anon88); //[pop]
    call(_if);
}
void _max__int()
{
    call(_dup2);
    call(_gt__int);
    push_function(_cat_anon89); //[pop]
    push_function(_cat_anon90); //[popd]
    call(_if);
}
void _odd()
{
    call(_dup);
    push_literal(2 );
    call(_mod__int);
    push_literal(1 );
    call(_eq);
}
void _gt__int()
{
    call(_lteq__int);
    call(_not);
}
void _gteq__int()
{
    call(_lt__int);
    call(_not);
}
void _lteq__int()
{
    call(_dup2);
    call(_eq);
    push_function(_cat_anon91); //[lt_int]
    call(_dip);
    call(_or);
}
void _run__tests()
{
    push_function(_cat_anon92); //[1 2 add_int 3 eq]
    call(_test);
    push_function(_cat_anon95); //[[1] [inc] compose apply 2 eq]
    call(_test);
    push_function(_cat_anon96); //[nil 1 cons uncons swap pop 1 eq]
    call(_test);
    push_function(_cat_anon97); //[42 7 div_int 6 eq]
    call(_test);
    push_function(_cat_anon98); //[2 dup add_int 4 eq]
    call(_test);
    push_function(_cat_anon99); //[nil empty popd 1 unit empty popd not 1 2 pair empty popd not and and]
    call(_test);
    push_function(_cat_anon100); //[1 1 eq]
    call(_test);
    push_function(_cat_anon103); //[false [false] [true] if]
    call(_test);
    push_function(_cat_anon106); //[true [1] [2] if 1 eq]
    call(_test);
    push_function(_cat_anon107); //[3 5 lt_int]
    call(_test);
    push_function(_cat_anon108); //[5 3 mod_int 2 eq]
    call(_test);
    push_function(_cat_anon109); //[5 3 mul_int 15 eq]
    call(_test);
    push_function(_cat_anon110); //[5 neg_int -5 eq]
    call(_test);
    push_function(_cat_anon111); //[nil nil eq]
    call(_test);
    push_function(_cat_anon112); //[3 5 pop 3 eq]
    call(_test);
    push_function(_cat_anon113); //[true 1 quote 2 quote if 1 eq]
    call(_test);
    push_function(_cat_anon114); //[1 2 swap pop 2 eq]
    call(_test);
    push_function(_cat_anon117); //[true [true] [false] if]
    call(_test);
    push_function(_cat_anon118); //[nil 2 cons 1 cons uncons pop uncons swap pop 2 eq]
    call(_test);
    push_function(_cat_anon121); //[1 [2 mul_int] [dup 100 lt_int] while 128 eq]
    call(_test);
    push_function(_cat_anon123); //[[1] apply 1 eq]
    call(_test);
    push_function(_cat_anon125); //[1 3 [inc] apply2 pop 2 eq]
    call(_test);
    push_function(_cat_anon127); //[1 3 [inc] dip pop 2 eq]
    call(_test);
    push_function(_cat_anon129); //[1 3 5 [inc] dip2 pop pop 2 eq]
    call(_test);
    push_function(_cat_anon130); //[true true and]
    call(_test);
    push_function(_cat_anon131); //[true false nand]
    call(_test);
    push_function(_cat_anon132); //[false false nor]
    call(_test);
    push_function(_cat_anon133); //[false not]
    call(_test);
    push_function(_cat_anon134); //[true false or]
    call(_test);
    push_function(_cat_anon135); //[0 eqz popd]
    call(_test);
    push_function(_cat_anon136); //[3 3 eqf apply popd]
    call(_test);
    push_function(_cat_anon137); //[3 5 neq]
    call(_test);
    push_function(_cat_anon138); //[3 5 neqf apply popd]
    call(_test);
    push_function(_cat_anon139); //[3 neqz popd]
    call(_test);
    push_function(_cat_anon141); //[1 2 [add_int] curry apply 3 eq]
    call(_test);
    push_function(_cat_anon143); //[1 2 [add_int] curry2 apply 3 eq]
    call(_test);
    push_function(_cat_anon146); //[1 [add_int] [2] rcompose apply 3 eq]
    call(_test);
    push_function(_cat_anon148); //[1 [add_int] 2 rcurry apply 3 eq]
    call(_test);
    push_function(_cat_anon150); //[nil [cons] 3 for 0 1 2 triple eq]
    call(_test);
    push_function(_cat_anon152); //[8 1 2 pair [add_int] for_each 11 eq]
    call(_test);
    push_function(_cat_anon154); //[1 [inc] 5 repeat 6 eq]
    call(_test);
    push_function(_cat_anon156); //[nil [cons] 3 rfor 3 2 1 triple eq]
    call(_test);
    push_function(_cat_anon159); //[1 [inc] [dup 3 gt_int] whilen 4 eq]
    call(_test);
    push_function(_cat_anon162); //[0 1 2 3 triple [uncons swap [add_int] dip] whilene 6 eq]
    call(_test);
    push_function(_cat_anon165); //[3 3 [[inc] dip dec] whilenz 6 eq]
    call(_test);
    push_function(_cat_anon166); //[1 unit 2 unit cat nil 1 cons 2 cons eq]
    call(_test);
    push_function(_cat_anon167); //[nil 1 2 consd pop head 1 eq]
    call(_test);
    push_function(_cat_anon168); //[1 2 pair count popd 2 eq]
    call(_test);
    push_function(_cat_anon170); //[1 2 3 triple [1 gt_int] count_while popd 2 eq]
    call(_test);
    push_function(_cat_anon171); //[3 4 pair 1 drop head 3 eq]
    call(_test);
    push_function(_cat_anon173); //[1 2 3 triple [2 gteq_int] drop_while 1 unit eq]
    call(_test);
    push_function(_cat_anon175); //[1 2 3 triple [2 mod_int 0 eq] filter 2 unit eq]
    call(_test);
    push_function(_cat_anon176); //[1 2 pair first popd 2 eq]
    call(_test);
    push_function(_cat_anon177); //[nil 1 unit cons 2 unit cons flatten 1 2 pair eq]
    call(_test);
    push_function(_cat_anon179); //[1 2 3 triple 0 [add_int] fold 6 eq]
    call(_test);
    push_function(_cat_anon182); //[0 [inc] [2 lt_int] gen 0 1 pair eq]
    call(_test);
    push_function(_cat_anon183); //[nil 1 cons 2 cons head 2 eq]
    call(_test);
    push_function(_cat_anon184); //[1 2 3 triple last popd 1 eq]
    call(_test);
    push_function(_cat_anon186); //[1 2 pair [3 mul_int] map head 6 eq]
    call(_test);
    push_function(_cat_anon187); //[1 2 3 triple mid popd 2 eq]
    call(_test);
    push_function(_cat_anon188); //[1 2 pair 3 4 pair move_head pop head 4 eq]
    call(_test);
    push_function(_cat_anon189); //[3 n 0 1 2 triple eq]
    call(_test);
    push_function(_cat_anon190); //[1 2 3 triple 2 nth popd 1 eq]
    call(_test);
    push_function(_cat_anon191); //[1 2 pair head 2 eq]
    call(_test);
    push_function(_cat_anon192); //[1 2 pair rev head 1 eq]
    call(_test);
    push_function(_cat_anon194); //[1 2 pair [3 mul_int] rmap head 3 eq]
    call(_test);
    push_function(_cat_anon195); //[1 2 pair 42 0 set_at head 42 eq]
    call(_test);
    push_function(_cat_anon196); //[1 unit small popd]
    call(_test);
    push_function(_cat_anon198); //[1 2 3 triple [2 mod_int 0 eq] split popd 1 3 pair eq]
    call(_test);
    push_function(_cat_anon199); //[1 2 3 triple 1 split_at pop 1 2 pair eq]
    call(_test);
    push_function(_cat_anon200); //[1 2 unit swons 2 1 pair eq]
    call(_test);
    push_function(_cat_anon201); //[3 4 pair tail 3 unit eq]
    call(_test);
    push_function(_cat_anon202); //[1 2 3 triple 2 take 2 3 pair eq]
    call(_test);
    push_function(_cat_anon204); //[1 2 3 triple [2 gt_int] take_while 3 unit eq]
    call(_test);
    push_function(_cat_anon205); //[1 2 3 triple 1 2 pair 3 cons eq]
    call(_test);
    push_function(_cat_anon206); //[1 2 pair unpair pop 1 eq]
    call(_test);
    push_function(_cat_anon207); //[1 unit nil 1 cons eq]
    call(_test);
    push_function(_cat_anon208); //[1 2 3 bury pop pop 3 eq]
    call(_test);
    push_function(_cat_anon209); //[1 2 3 dig popd popd 1 eq]
    call(_test);
    push_function(_cat_anon210); //[1 2 dup2 pop popd popd 1 eq]
    call(_test);
    push_function(_cat_anon211); //[1 2 dupd pop popd 1 eq]
    call(_test);
    push_function(_cat_anon212); //[1 2 over popd popd 1 eq]
    call(_test);
    push_function(_cat_anon213); //[1 2 3 peek popd popd popd 1 eq]
    call(_test);
    push_function(_cat_anon214); //[1 2 3 poke pop 3 eq]
    call(_test);
    push_function(_cat_anon215); //[1 2 3 pop2 1 eq]
    call(_test);
    push_function(_cat_anon216); //[1 2 3 4 pop3 1 eq]
    call(_test);
    push_function(_cat_anon217); //[1 2 popd 2 eq]
    call(_test);
    push_function(_cat_anon218); //[1 2 3 4 swap2 pop3 3 eq]
    call(_test);
    push_function(_cat_anon219); //[1 2 3 swapd pop2 2 eq]
    call(_test);
    push_function(_cat_anon220); //[1 2 under pop2 2 eq]
    call(_test);
    push_function(_cat_anon221); //[3 dec 2 eq]
    call(_test);
    push_function(_cat_anon222); //[2 even popd]
    call(_test);
    push_function(_cat_anon223); //[3 inc 4 eq]
    call(_test);
    push_function(_cat_anon224); //[5 3 sub_int 2 eq]
    call(_test);
    push_function(_cat_anon225); //[3 5 min_int 3 eq]
    call(_test);
    push_function(_cat_anon226); //[3 5 max_int 5 eq]
    call(_test);
    push_function(_cat_anon227); //[3 odd popd]
    call(_test);
    push_function(_cat_anon228); //[5 3 gt_int]
    call(_test);
    push_function(_cat_anon229); //[5 5 gteq_int]
    call(_test);
    push_function(_cat_anon230); //[3 5 lteq_int]
    call(_test);
}
void _cat_anon0()
{
}
void _cat_anon1()
{
    call(_apply);
}
void _cat_anon2()
{
    call(_dip);
}
void _cat_anon3()
{
    call(_k);
}
void _cat_anon4()
{
    call(_s);
}
void _cat_anon5()
{
    push_function(_cat_anon4); //[s]
    call(_k);
}
void _cat_anon6()
{
    call(_k);
}
void _cat_anon7()
{
    push_function(_cat_anon6); //[k]
    call(_k);
}
void _cat_anon8()
{
    call(_s);
}
void _cat_anon9()
{
    call(_b);
}
void _cat_anon10()
{
    push_function(_cat_anon8); //[s]
    push_function(_cat_anon9); //[b]
    call(_b);
}
void _cat_anon11()
{
    call(_b);
}
void _cat_anon12()
{
    call(_k);
}
void _cat_anon13()
{
    call(_k);
}
void _cat_anon14()
{
    call(_pop);
}
void _cat_anon15()
{
    call(_i);
}
void _cat_anon16()
{
    call(_m);
}
void _cat_anon17()
{
    call(_b);
}
void _cat_anon18()
{
    call(_i);
}
void _cat_anon19()
{
    call(_t);
}
void _cat_anon20()
{
    call(_b);
}
void _cat_anon21()
{
    call(_curry);
}
void _cat_anon22()
{
    call(_i);
}
void _cat_anon23()
{
    call(_o);
}
void _cat_anon24()
{
    call(_t);
}
void _cat_anon25()
{
    call(_c);
}
void _cat_anon26()
{
    call(_r);
}
void _cat_anon27()
{
    call(_m);
}
void _cat_anon28()
{
    push_function(_cat_anon26); //[r]
    push_function(_cat_anon27); //[m]
    call(_b);
}
void _cat_anon29()
{
    call(_y);
}
void _cat_anon30()
{
    call(_false);
}
void _cat_anon31()
{
    call(_false);
}
void _cat_anon32()
{
    call(_true);
}
void _cat_anon33()
{
    call(_true);
}
void _cat_anon34()
{
    call(_dupd);
    call(_eq);
}
void _cat_anon35()
{
    call(_dupd);
    call(_neq);
}
void _cat_anon36()
{
    call(_quote);
}
void _cat_anon37()
{
    call(_dip);
    call(_inc);
}
void _cat_anon38()
{
    call(_dup);
}
void _cat_anon39()
{
    call(_dip);
}
void _cat_anon40()
{
    call(_uncons);
    call(_swap);
}
void _cat_anon41()
{
    call(_dip);
    call(_dec);
}
void _cat_anon42()
{
    call(_neqz);
}
void _cat_anon43()
{
    call(_dip);
    call(_dec);
}
void _cat_anon44()
{
    call(_dup);
}
void _cat_anon45()
{
    call(_not);
}
void _cat_anon46()
{
    call(_empty);
    call(_not);
}
void _cat_anon47()
{
    call(_neqz);
}
void _cat_anon48()
{
    call(_cons);
}
void _cat_anon49()
{
    call(_cons);
}
void _cat_anon50()
{
    call(_pop);
    call(_inc);
}
void _cat_anon51()
{
    call(_dup);
    push_literal(0 );
    call(_swap);
}
void _cat_anon52()
{
    call(_inc);
}
void _cat_anon53()
{
    push_function(_cat_anon52); //[inc]
    call(_dip);
}
void _cat_anon54()
{
    call(_uncons);
}
void _cat_anon55()
{
    call(_tail);
}
void _cat_anon56()
{
    push_function(_cat_anon55); //[tail]
    call(_dip);
    call(_dec);
}
void _cat_anon57()
{
    call(_rev);
}
void _cat_anon58()
{
    call(_cons);
}
void _cat_anon59()
{
    call(_pop);
}
void _cat_anon60()
{
    push_function(_cat_anon58); //[cons]
    push_function(_cat_anon59); //[pop]
    call(_if);
}
void _cat_anon61()
{
    call(_dup);
}
void _cat_anon62()
{
    call(_cat);
}
void _cat_anon63()
{
    call(_dip);
}
void _cat_anon64()
{
    call(_uncons);
    call(_swap);
}
void _cat_anon65()
{
    call(_bury);
}
void _cat_anon66()
{
    call(_dup);
    call(_consd);
}
void _cat_anon67()
{
    push_function(_cat_anon66); //[dup consd]
    call(_rcompose);
}
void _cat_anon68()
{
    call(_dup);
}
void _cat_anon69()
{
    call(_cons);
}
void _cat_anon70()
{
    call(_unit);
}
void _cat_anon71()
{
    call(_cons);
}
void _cat_anon72()
{
    call(_cons);
}
void _cat_anon73()
{
    call(_tail);
    call(_swons);
}
void _cat_anon74()
{
    call(_filter);
}
void _cat_anon75()
{
    call(_not);
}
void _cat_anon76()
{
    call(_move__head);
}
void _cat_anon77()
{
    call(_move__head);
}
void _cat_anon78()
{
    push_function(_cat_anon77); //[move_head]
    call(_dip);
    call(_dec);
}
void _cat_anon79()
{
    call(_pair);
}
void _cat_anon80()
{
    call(_head);
}
void _cat_anon81()
{
    call(_dup);
}
void _cat_anon82()
{
    call(_dupd);
}
void _cat_anon83()
{
    call(_popd);
}
void _cat_anon84()
{
    call(_pop);
}
void _cat_anon85()
{
    call(_bury);
}
void _cat_anon86()
{
    call(_swap);
}
void _cat_anon87()
{
    call(_popd);
}
void _cat_anon88()
{
    call(_pop);
}
void _cat_anon89()
{
    call(_pop);
}
void _cat_anon90()
{
    call(_popd);
}
void _cat_anon91()
{
    call(_lt__int);
}
void _cat_anon92()
{
    push_literal(1 );
    push_literal(2 );
    call(_add__int);
    push_literal(3 );
    call(_eq);
}
void _cat_anon93()
{
    push_literal(1);
}
void _cat_anon94()
{
    call(_inc);
}
void _cat_anon95()
{
    push_function(_cat_anon93); //[1]
    push_function(_cat_anon94); //[inc]
    call(_compose);
    call(_apply);
    push_literal(2 );
    call(_eq);
}
void _cat_anon96()
{
    call(_nil);
    push_literal(1 );
    call(_cons);
    call(_uncons);
    call(_swap);
    call(_pop);
    push_literal(1 );
    call(_eq);
}
void _cat_anon97()
{
    push_literal(42 );
    push_literal(7 );
    call(_div__int);
    push_literal(6 );
    call(_eq);
}
void _cat_anon98()
{
    push_literal(2 );
    call(_dup);
    call(_add__int);
    push_literal(4 );
    call(_eq);
}
void _cat_anon99()
{
    call(_nil);
    call(_empty);
    call(_popd);
    push_literal(1 );
    call(_unit);
    call(_empty);
    call(_popd);
    call(_not);
    push_literal(1 );
    push_literal(2 );
    call(_pair);
    call(_empty);
    call(_popd);
    call(_not);
    call(_and);
    call(_and);
}
void _cat_anon100()
{
    push_literal(1 );
    push_literal(1 );
    call(_eq);
}
void _cat_anon101()
{
    call(_false);
}
void _cat_anon102()
{
    call(_true);
}
void _cat_anon103()
{
    call(_false);
    push_function(_cat_anon101); //[false]
    push_function(_cat_anon102); //[true]
    call(_if);
}
void _cat_anon104()
{
    push_literal(1);
}
void _cat_anon105()
{
    push_literal(2);
}
void _cat_anon106()
{
    call(_true);
    push_function(_cat_anon104); //[1]
    push_function(_cat_anon105); //[2]
    call(_if);
    push_literal(1 );
    call(_eq);
}
void _cat_anon107()
{
    push_literal(3 );
    push_literal(5 );
    call(_lt__int);
}
void _cat_anon108()
{
    push_literal(5 );
    push_literal(3 );
    call(_mod__int);
    push_literal(2 );
    call(_eq);
}
void _cat_anon109()
{
    push_literal(5 );
    push_literal(3 );
    call(_mul__int);
    push_literal(15 );
    call(_eq);
}
void _cat_anon110()
{
    push_literal(5 );
    call(_neg__int);
    push_literal(-5 );
    call(_eq);
}
void _cat_anon111()
{
    call(_nil);
    call(_nil);
    call(_eq);
}
void _cat_anon112()
{
    push_literal(3 );
    push_literal(5 );
    call(_pop);
    push_literal(3 );
    call(_eq);
}
void _cat_anon113()
{
    call(_true);
    push_literal(1 );
    call(_quote);
    push_literal(2 );
    call(_quote);
    call(_if);
    push_literal(1 );
    call(_eq);
}
void _cat_anon114()
{
    push_literal(1 );
    push_literal(2 );
    call(_swap);
    call(_pop);
    push_literal(2 );
    call(_eq);
}
void _cat_anon115()
{
    call(_true);
}
void _cat_anon116()
{
    call(_false);
}
void _cat_anon117()
{
    call(_true);
    push_function(_cat_anon115); //[true]
    push_function(_cat_anon116); //[false]
    call(_if);
}
void _cat_anon118()
{
    call(_nil);
    push_literal(2 );
    call(_cons);
    push_literal(1 );
    call(_cons);
    call(_uncons);
    call(_pop);
    call(_uncons);
    call(_swap);
    call(_pop);
    push_literal(2 );
    call(_eq);
}
void _cat_anon119()
{
    push_literal(2 );
    call(_mul__int);
}
void _cat_anon120()
{
    call(_dup);
    push_literal(100 );
    call(_lt__int);
}
void _cat_anon121()
{
    push_literal(1 );
    push_function(_cat_anon119); //[2 mul_int]
    push_function(_cat_anon120); //[dup 100 lt_int]
    call(_while);
    push_literal(128 );
    call(_eq);
}
void _cat_anon122()
{
    push_literal(1);
}
void _cat_anon123()
{
    push_function(_cat_anon122); //[1]
    call(_apply);
    push_literal(1 );
    call(_eq);
}
void _cat_anon124()
{
    call(_inc);
}
void _cat_anon125()
{
    push_literal(1 );
    push_literal(3 );
    push_function(_cat_anon124); //[inc]
    call(_apply2);
    call(_pop);
    push_literal(2 );
    call(_eq);
}
void _cat_anon126()
{
    call(_inc);
}
void _cat_anon127()
{
    push_literal(1 );
    push_literal(3 );
    push_function(_cat_anon126); //[inc]
    call(_dip);
    call(_pop);
    push_literal(2 );
    call(_eq);
}
void _cat_anon128()
{
    call(_inc);
}
void _cat_anon129()
{
    push_literal(1 );
    push_literal(3 );
    push_literal(5 );
    push_function(_cat_anon128); //[inc]
    call(_dip2);
    call(_pop);
    call(_pop);
    push_literal(2 );
    call(_eq);
}
void _cat_anon130()
{
    call(_true);
    call(_true);
    call(_and);
}
void _cat_anon131()
{
    call(_true);
    call(_false);
    call(_nand);
}
void _cat_anon132()
{
    call(_false);
    call(_false);
    call(_nor);
}
void _cat_anon133()
{
    call(_false);
    call(_not);
}
void _cat_anon134()
{
    call(_true);
    call(_false);
    call(_or);
}
void _cat_anon135()
{
    push_literal(0 );
    call(_eqz);
    call(_popd);
}
void _cat_anon136()
{
    push_literal(3 );
    push_literal(3 );
    call(_eqf);
    call(_apply);
    call(_popd);
}
void _cat_anon137()
{
    push_literal(3 );
    push_literal(5 );
    call(_neq);
}
void _cat_anon138()
{
    push_literal(3 );
    push_literal(5 );
    call(_neqf);
    call(_apply);
    call(_popd);
}
void _cat_anon139()
{
    push_literal(3 );
    call(_neqz);
    call(_popd);
}
void _cat_anon140()
{
    call(_add__int);
}
void _cat_anon141()
{
    push_literal(1 );
    push_literal(2 );
    push_function(_cat_anon140); //[add_int]
    call(_curry);
    call(_apply);
    push_literal(3 );
    call(_eq);
}
void _cat_anon142()
{
    call(_add__int);
}
void _cat_anon143()
{
    push_literal(1 );
    push_literal(2 );
    push_function(_cat_anon142); //[add_int]
    call(_curry2);
    call(_apply);
    push_literal(3 );
    call(_eq);
}
void _cat_anon144()
{
    call(_add__int);
}
void _cat_anon145()
{
    push_literal(2);
}
void _cat_anon146()
{
    push_literal(1 );
    push_function(_cat_anon144); //[add_int]
    push_function(_cat_anon145); //[2]
    call(_rcompose);
    call(_apply);
    push_literal(3 );
    call(_eq);
}
void _cat_anon147()
{
    call(_add__int);
}
void _cat_anon148()
{
    push_literal(1 );
    push_function(_cat_anon147); //[add_int]
    push_literal(2 );
    call(_rcurry);
    call(_apply);
    push_literal(3 );
    call(_eq);
}
void _cat_anon149()
{
    call(_cons);
}
void _cat_anon150()
{
    call(_nil);
    push_function(_cat_anon149); //[cons]
    push_literal(3 );
    call(_for);
    push_literal(0 );
    push_literal(1 );
    push_literal(2 );
    call(_triple);
    call(_eq);
}
void _cat_anon151()
{
    call(_add__int);
}
void _cat_anon152()
{
    push_literal(8 );
    push_literal(1 );
    push_literal(2 );
    call(_pair);
    push_function(_cat_anon151); //[add_int]
    call(_for__each);
    push_literal(11 );
    call(_eq);
}
void _cat_anon153()
{
    call(_inc);
}
void _cat_anon154()
{
    push_literal(1 );
    push_function(_cat_anon153); //[inc]
    push_literal(5 );
    call(_repeat);
    push_literal(6 );
    call(_eq);
}
void _cat_anon155()
{
    call(_cons);
}
void _cat_anon156()
{
    call(_nil);
    push_function(_cat_anon155); //[cons]
    push_literal(3 );
    call(_rfor);
    push_literal(3 );
    push_literal(2 );
    push_literal(1 );
    call(_triple);
    call(_eq);
}
void _cat_anon157()
{
    call(_inc);
}
void _cat_anon158()
{
    call(_dup);
    push_literal(3 );
    call(_gt__int);
}
void _cat_anon159()
{
    push_literal(1 );
    push_function(_cat_anon157); //[inc]
    push_function(_cat_anon158); //[dup 3 gt_int]
    call(_whilen);
    push_literal(4 );
    call(_eq);
}
void _cat_anon160()
{
    call(_add__int);
}
void _cat_anon161()
{
    call(_uncons);
    call(_swap);
    push_function(_cat_anon160); //[add_int]
    call(_dip);
}
void _cat_anon162()
{
    push_literal(0 );
    push_literal(1 );
    push_literal(2 );
    push_literal(3 );
    call(_triple);
    push_function(_cat_anon161); //[uncons swap [add_int] dip]
    call(_whilene);
    push_literal(6 );
    call(_eq);
}
void _cat_anon163()
{
    call(_inc);
}
void _cat_anon164()
{
    push_function(_cat_anon163); //[inc]
    call(_dip);
    call(_dec);
}
void _cat_anon165()
{
    push_literal(3 );
    push_literal(3 );
    push_function(_cat_anon164); //[[inc] dip dec]
    call(_whilenz);
    push_literal(6 );
    call(_eq);
}
void _cat_anon166()
{
    push_literal(1 );
    call(_unit);
    push_literal(2 );
    call(_unit);
    call(_cat);
    call(_nil);
    push_literal(1 );
    call(_cons);
    push_literal(2 );
    call(_cons);
    call(_eq);
}
void _cat_anon167()
{
    call(_nil);
    push_literal(1 );
    push_literal(2 );
    call(_consd);
    call(_pop);
    call(_head);
    push_literal(1 );
    call(_eq);
}
void _cat_anon168()
{
    push_literal(1 );
    push_literal(2 );
    call(_pair);
    call(_count);
    call(_popd);
    push_literal(2 );
    call(_eq);
}
void _cat_anon169()
{
    push_literal(1 );
    call(_gt__int);
}
void _cat_anon170()
{
    push_literal(1 );
    push_literal(2 );
    push_literal(3 );
    call(_triple);
    push_function(_cat_anon169); //[1 gt_int]
    call(_count__while);
    call(_popd);
    push_literal(2 );
    call(_eq);
}
void _cat_anon171()
{
    push_literal(3 );
    push_literal(4 );
    call(_pair);
    push_literal(1 );
    call(_drop);
    call(_head);
    push_literal(3 );
    call(_eq);
}
void _cat_anon172()
{
    push_literal(2 );
    call(_gteq__int);
}
void _cat_anon173()
{
    push_literal(1 );
    push_literal(2 );
    push_literal(3 );
    call(_triple);
    push_function(_cat_anon172); //[2 gteq_int]
    call(_drop__while);
    push_literal(1 );
    call(_unit);
    call(_eq);
}
void _cat_anon174()
{
    push_literal(2 );
    call(_mod__int);
    push_literal(0 );
    call(_eq);
}
void _cat_anon175()
{
    push_literal(1 );
    push_literal(2 );
    push_literal(3 );
    call(_triple);
    push_function(_cat_anon174); //[2 mod_int 0 eq]
    call(_filter);
    push_literal(2 );
    call(_unit);
    call(_eq);
}
void _cat_anon176()
{
    push_literal(1 );
    push_literal(2 );
    call(_pair);
    call(_first);
    call(_popd);
    push_literal(2 );
    call(_eq);
}
void _cat_anon177()
{
    call(_nil);
    push_literal(1 );
    call(_unit);
    call(_cons);
    push_literal(2 );
    call(_unit);
    call(_cons);
    call(_flatten);
    push_literal(1 );
    push_literal(2 );
    call(_pair);
    call(_eq);
}
void _cat_anon178()
{
    call(_add__int);
}
void _cat_anon179()
{
    push_literal(1 );
    push_literal(2 );
    push_literal(3 );
    call(_triple);
    push_literal(0 );
    push_function(_cat_anon178); //[add_int]
    call(_fold);
    push_literal(6 );
    call(_eq);
}
void _cat_anon180()
{
    call(_inc);
}
void _cat_anon181()
{
    push_literal(2 );
    call(_lt__int);
}
void _cat_anon182()
{
    push_literal(0 );
    push_function(_cat_anon180); //[inc]
    push_function(_cat_anon181); //[2 lt_int]
    call(_gen);
    push_literal(0 );
    push_literal(1 );
    call(_pair);
    call(_eq);
}
void _cat_anon183()
{
    call(_nil);
    push_literal(1 );
    call(_cons);
    push_literal(2 );
    call(_cons);
    call(_head);
    push_literal(2 );
    call(_eq);
}
void _cat_anon184()
{
    push_literal(1 );
    push_literal(2 );
    push_literal(3 );
    call(_triple);
    call(_last);
    call(_popd);
    push_literal(1 );
    call(_eq);
}
void _cat_anon185()
{
    push_literal(3 );
    call(_mul__int);
}
void _cat_anon186()
{
    push_literal(1 );
    push_literal(2 );
    call(_pair);
    push_function(_cat_anon185); //[3 mul_int]
    call(_map);
    call(_head);
    push_literal(6 );
    call(_eq);
}
void _cat_anon187()
{
    push_literal(1 );
    push_literal(2 );
    push_literal(3 );
    call(_triple);
    call(_mid);
    call(_popd);
    push_literal(2 );
    call(_eq);
}
void _cat_anon188()
{
    push_literal(1 );
    push_literal(2 );
    call(_pair);
    push_literal(3 );
    push_literal(4 );
    call(_pair);
    call(_move__head);
    call(_pop);
    call(_head);
    push_literal(4 );
    call(_eq);
}
void _cat_anon189()
{
    push_literal(3 );
    call(_n);
    push_literal(0 );
    push_literal(1 );
    push_literal(2 );
    call(_triple);
    call(_eq);
}
void _cat_anon190()
{
    push_literal(1 );
    push_literal(2 );
    push_literal(3 );
    call(_triple);
    push_literal(2 );
    call(_nth);
    call(_popd);
    push_literal(1 );
    call(_eq);
}
void _cat_anon191()
{
    push_literal(1 );
    push_literal(2 );
    call(_pair);
    call(_head);
    push_literal(2 );
    call(_eq);
}
void _cat_anon192()
{
    push_literal(1 );
    push_literal(2 );
    call(_pair);
    call(_rev);
    call(_head);
    push_literal(1 );
    call(_eq);
}
void _cat_anon193()
{
    push_literal(3 );
    call(_mul__int);
}
void _cat_anon194()
{
    push_literal(1 );
    push_literal(2 );
    call(_pair);
    push_function(_cat_anon193); //[3 mul_int]
    call(_rmap);
    call(_head);
    push_literal(3 );
    call(_eq);
}
void _cat_anon195()
{
    push_literal(1 );
    push_literal(2 );
    call(_pair);
    push_literal(42 );
    push_literal(0 );
    call(_set__at);
    call(_head);
    push_literal(42 );
    call(_eq);
}
void _cat_anon196()
{
    push_literal(1 );
    call(_unit);
    call(_small);
    call(_popd);
}
void _cat_anon197()
{
    push_literal(2 );
    call(_mod__int);
    push_literal(0 );
    call(_eq);
}
void _cat_anon198()
{
    push_literal(1 );
    push_literal(2 );
    push_literal(3 );
    call(_triple);
    push_function(_cat_anon197); //[2 mod_int 0 eq]
    call(_split);
    call(_popd);
    push_literal(1 );
    push_literal(3 );
    call(_pair);
    call(_eq);
}
void _cat_anon199()
{
    push_literal(1 );
    push_literal(2 );
    push_literal(3 );
    call(_triple);
    push_literal(1 );
    call(_split__at);
    call(_pop);
    push_literal(1 );
    push_literal(2 );
    call(_pair);
    call(_eq);
}
void _cat_anon200()
{
    push_literal(1 );
    push_literal(2 );
    call(_unit);
    call(_swons);
    push_literal(2 );
    push_literal(1 );
    call(_pair);
    call(_eq);
}
void _cat_anon201()
{
    push_literal(3 );
    push_literal(4 );
    call(_pair);
    call(_tail);
    push_literal(3 );
    call(_unit);
    call(_eq);
}
void _cat_anon202()
{
    push_literal(1 );
    push_literal(2 );
    push_literal(3 );
    call(_triple);
    push_literal(2 );
    call(_take);
    push_literal(2 );
    push_literal(3 );
    call(_pair);
    call(_eq);
}
void _cat_anon203()
{
    push_literal(2 );
    call(_gt__int);
}
void _cat_anon204()
{
    push_literal(1 );
    push_literal(2 );
    push_literal(3 );
    call(_triple);
    push_function(_cat_anon203); //[2 gt_int]
    call(_take__while);
    push_literal(3 );
    call(_unit);
    call(_eq);
}
void _cat_anon205()
{
    push_literal(1 );
    push_literal(2 );
    push_literal(3 );
    call(_triple);
    push_literal(1 );
    push_literal(2 );
    call(_pair);
    push_literal(3 );
    call(_cons);
    call(_eq);
}
void _cat_anon206()
{
    push_literal(1 );
    push_literal(2 );
    call(_pair);
    call(_unpair);
    call(_pop);
    push_literal(1 );
    call(_eq);
}
void _cat_anon207()
{
    push_literal(1 );
    call(_unit);
    call(_nil);
    push_literal(1 );
    call(_cons);
    call(_eq);
}
void _cat_anon208()
{
    push_literal(1 );
    push_literal(2 );
    push_literal(3 );
    call(_bury);
    call(_pop);
    call(_pop);
    push_literal(3 );
    call(_eq);
}
void _cat_anon209()
{
    push_literal(1 );
    push_literal(2 );
    push_literal(3 );
    call(_dig);
    call(_popd);
    call(_popd);
    push_literal(1 );
    call(_eq);
}
void _cat_anon210()
{
    push_literal(1 );
    push_literal(2 );
    call(_dup2);
    call(_pop);
    call(_popd);
    call(_popd);
    push_literal(1 );
    call(_eq);
}
void _cat_anon211()
{
    push_literal(1 );
    push_literal(2 );
    call(_dupd);
    call(_pop);
    call(_popd);
    push_literal(1 );
    call(_eq);
}
void _cat_anon212()
{
    push_literal(1 );
    push_literal(2 );
    call(_over);
    call(_popd);
    call(_popd);
    push_literal(1 );
    call(_eq);
}
void _cat_anon213()
{
    push_literal(1 );
    push_literal(2 );
    push_literal(3 );
    call(_peek);
    call(_popd);
    call(_popd);
    call(_popd);
    push_literal(1 );
    call(_eq);
}
void _cat_anon214()
{
    push_literal(1 );
    push_literal(2 );
    push_literal(3 );
    call(_poke);
    call(_pop);
    push_literal(3 );
    call(_eq);
}
void _cat_anon215()
{
    push_literal(1 );
    push_literal(2 );
    push_literal(3 );
    call(_pop2);
    push_literal(1 );
    call(_eq);
}
void _cat_anon216()
{
    push_literal(1 );
    push_literal(2 );
    push_literal(3 );
    push_literal(4 );
    call(_pop3);
    push_literal(1 );
    call(_eq);
}
void _cat_anon217()
{
    push_literal(1 );
    push_literal(2 );
    call(_popd);
    push_literal(2 );
    call(_eq);
}
void _cat_anon218()
{
    push_literal(1 );
    push_literal(2 );
    push_literal(3 );
    push_literal(4 );
    call(_swap2);
    call(_pop3);
    push_literal(3 );
    call(_eq);
}
void _cat_anon219()
{
    push_literal(1 );
    push_literal(2 );
    push_literal(3 );
    call(_swapd);
    call(_pop2);
    push_literal(2 );
    call(_eq);
}
void _cat_anon220()
{
    push_literal(1 );
    push_literal(2 );
    call(_under);
    call(_pop2);
    push_literal(2 );
    call(_eq);
}
void _cat_anon221()
{
    push_literal(3 );
    call(_dec);
    push_literal(2 );
    call(_eq);
}
void _cat_anon222()
{
    push_literal(2 );
    call(_even);
    call(_popd);
}
void _cat_anon223()
{
    push_literal(3 );
    call(_inc);
    push_literal(4 );
    call(_eq);
}
void _cat_anon224()
{
    push_literal(5 );
    push_literal(3 );
    call(_sub__int);
    push_literal(2 );
    call(_eq);
}
void _cat_anon225()
{
    push_literal(3 );
    push_literal(5 );
    call(_min__int);
    push_literal(3 );
    call(_eq);
}
void _cat_anon226()
{
    push_literal(3 );
    push_literal(5 );
    call(_max__int);
    push_literal(5 );
    call(_eq);
}
void _cat_anon227()
{
    push_literal(3 );
    call(_odd);
    call(_popd);
}
void _cat_anon228()
{
    push_literal(5 );
    push_literal(3 );
    call(_gt__int);
}
void _cat_anon229()
{
    push_literal(5 );
    push_literal(5 );
    call(_gteq__int);
}
void _cat_anon230()
{
    push_literal(3 );
    push_literal(5 );
    call(_lteq__int);
}
